package com.example.carapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
