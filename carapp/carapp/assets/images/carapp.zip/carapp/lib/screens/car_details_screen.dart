import 'package:flutter/material.dart';

class CarDetailsScreen extends StatelessWidget {
  const CarDetailsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Retrieve the car details passed via Navigator.
    final Map<String, String> car =
    ModalRoute.of(context)!.settings.arguments as Map<String, String>;

    return Scaffold(
      appBar: AppBar(
        title: Text(car['model'] ?? 'Car Details'),
      ),
      body: SingleChildScrollView(
        padding:
        const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Car image.
            Image.asset(
              car['image']!,
              width: double.infinity,
              height: 250,
              fit: BoxFit.cover,
            ),
            const SizedBox(height: 16),
            // Car model.
            Text(
              car['model']!,
              style: const TextStyle(
                  fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            // Car price.
            Text(
              car['price']!,
              style: const TextStyle(fontSize: 20, color: Colors.green),
            ),
            // You can add more car details here (e.g., seats, horsepower, transmission).
            const SizedBox(height: 20),
            // "Buy or Rent" button.
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  // Display the bottom sheet options when tapped.
                  showModalBottomSheet(
                    context: context,
                    builder: (BuildContext context) {
                      return Container(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            ListTile(
                              leading: const Icon(Icons.shopping_cart),
                              title: const Text('Buy'),
                              onTap: () {
                                Navigator.pop(context);
                                // Replace with your Buy flow.
                                ScaffoldMessenger.of(context)
                                    .showSnackBar(
                                  const SnackBar(
                                    content: Text(
                                        "Buy functionality coming soon!"),
                                  ),
                                );
                              },
                            ),
                            const Divider(),
                            ListTile(
                              leading: const Icon(Icons.directions_car),
                              title: const Text('Rent'),
                              onTap: () {
                                Navigator.pop(context);
                                // Replace with your Rent flow.
                                ScaffoldMessenger.of(context)
                                    .showSnackBar(
                                  const SnackBar(
                                    content: Text(
                                        "Rent functionality coming soon!"),
                                  ),
                                );
                              },
                            ),
                          ],
                        ),
                      );
                    },
                  );
                },
                child: const Text('Buy or Rent'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
