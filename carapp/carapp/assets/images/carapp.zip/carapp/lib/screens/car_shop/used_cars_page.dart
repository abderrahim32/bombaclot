import 'package:flutter/material.dart';

class UsedCarsPage extends StatelessWidget {
  const UsedCarsPage({Key? key}) : super(key: key);

  // Dummy list of used cars.
  final List<Map<String, String>> usedCars = const [
    {
      'image': 'assets/images/audi.png',
      'model': 'Audi A4 2019',
      'price': 'DA35,00,000',
      'condition': 'Good',
    },
    {
      'image': 'assets/images/ford_mustang.png',
      'model': 'Ford Mustang 2017',
      'price': 'DA50,00,000',
      'condition': 'Very Good',
    },
    // Add more used cars as needed.
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Used Cars'),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemCount: usedCars.length,
        itemBuilder: (context, index) {
          final car = usedCars[index];
          return Card(
            elevation: 4,
            margin: const EdgeInsets.only(bottom: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.asset(
                  car['image']!,
                  width: double.infinity,
                  height: 200,
                  fit: BoxFit.cover,
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        car['model']!,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        car['price']!,
                        style: const TextStyle(
                          fontSize: 18,
                          color: Colors.green,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Condition: ${car['condition']}',
                        style: const TextStyle(color: Colors.grey),
                      ),
                      const SizedBox(height: 8),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.pushNamed(
                            context,
                            '/details',
                            arguments: car,
                          );
                        },
                        child: const Text('View Details'),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
