import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  // Dummy list of categories.
  final List<String> categories = const [
    "SUV",
    "ELC",
    "VAN",
    "SDN",
  ];

  // Dummy list of car choices with details.
  final List<Map<String, String>> carChoices = const [
    {
      'image': 'assets/images/ford_mustang.png', // Ensure this asset exists.
      'model': 'Ford Mustang GT 2022',
      'price': 'DA74,00,000',
      'rating': '4.9',
      'reviews': '80 reviews',
      'seats': '2 seats',
      'horsepower': '515 hp',
      'topSpeed': '230 km/h',
      'transmission': 'Automatic Transmission',
    },
    {
      'image': 'assets/images/mercedes.png', // Example image.
      'model': 'Mercedes Benz S-Class 2023',
      'price': 'DA1,20,00,000',
      'rating': '4.8',
      'reviews': '60 reviews',
      'seats': '4 seats',
      'horsepower': '450 hp',
      'topSpeed': '250 km/h',
      'transmission': 'Automatic Transmission',
    },
    {
      'image': 'assets/images/audi.png', // Example image.
      'model': 'Audi A8 2021',
      'price': 'DA85,00,000',
      'rating': '4.7',
      'reviews': '55 reviews',
      'seats': '5 seats',
      'horsepower': '400 hp',
      'topSpeed': '240 km/h',
      'transmission': 'Automatic Transmission',
    },
    // You can add more car entries as needed.
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CarApp Home'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              // Implement search functionality, if needed.
            },
          ),
          IconButton(
            icon: const Icon(Icons.notifications),
            onPressed: () {
              // A placeholder for notifications.
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("No notifications available")),
              );
            },
          ),
        ],
      ),
      drawer: _buildDrawer(context),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        physics: const BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Heading Section.
            const Text(
              'Explore Cars',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),

            // Categories Horizontal List.
            SizedBox(
              height: 40,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: categories.length,
                separatorBuilder: (context, index) => const SizedBox(width: 12),
                itemBuilder: (context, index) {
                  return Chip(
                    label: Text(
                      categories[index],
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    backgroundColor: Colors.blue.shade100,
                  );
                },
              ),
            ),
            const SizedBox(height: 24),

            // Section: Car Listings.
            const Text(
              'Available Cars',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 16),

            // GridView to show multiple vehicles.
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: carChoices.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, // Two vehicles per row.
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: 0.7,
              ),
              itemBuilder: (context, index) {
                final car = carChoices[index];
                return _buildCarCard(context, car);
              },
            ),
          ],
        ),
      ),
    );
  }

  // Builds each car card for the grid.
  Widget _buildCarCard(BuildContext context, Map<String, String> car) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Image: Expands to fill available vertical space.
          Expanded(
            child: Image.asset(
              car['image']!,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  car['model']!,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Text(
                  car['price']!,
                  style: const TextStyle(fontSize: 14, color: Colors.green),
                ),
                const SizedBox(height: 8),
                // "View Details" Button.
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pushNamed(context, '/details', arguments: car);
                    },
                    child: const Text('View Details'),
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size(double.infinity, 36),
                      textStyle: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Builds the collapsible sidebar (Drawer) with multiple options.
  Widget _buildDrawer(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          // Drawer header.
          DrawerHeader(
            decoration: const BoxDecoration(
              color: Colors.blue,
            ),
            child: const Text(
              'CarApp Menu',
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
              ),
            ),
          ),
          // ExpansionTile for Car Shop options.
          ExpansionTile(
            leading: const Icon(Icons.car_rental),
            title: const Text('Car Shop'),
            children: [
              ListTile(
                leading: const Icon(Icons.directions_car),
                title: const Text('New Cars'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/carShop/new');
                },
              ),
              ListTile(
                leading: const Icon(Icons.car_repair),
                title: const Text('Used Cars'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/carShop/used');
                },
              ),
            ],
          ),
          // ExpansionTile for Car Rent options.
          ExpansionTile(
            leading: const Icon(Icons.taxi_alert),
            title: const Text('Car Rent'),
            children: [
              ListTile(
                leading: const Icon(Icons.time_to_leave),
                title: const Text('Short Term Rent'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/carRent/shortTerm');
                },
              ),
              ListTile(
                leading: const Icon(Icons.calendar_today),
                title: const Text('Long Term Rent'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/carRent/longTerm');
                },
              ),
            ],
          ),
          // Additional options.
          ListTile(
            leading: const Icon(Icons.info),
            title: const Text('About'),
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/about');
            },
          ),
          ListTile(
            leading: const Icon(Icons.logout),
            title: const Text('Logout'),
            onTap: () {
              Navigator.pop(context);
              Navigator.pushReplacementNamed(context, '/login');
            },
          ),
        ],
      ),
    );
  }
}
