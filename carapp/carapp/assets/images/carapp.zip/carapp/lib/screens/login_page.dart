import 'package:flutter/material.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  void _login() {
    // Here add your login logic later (e.g., Firebase authentication)
    Navigator.pushReplacementNamed(context, '/home');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Log in"),
        actions: [
          IconButton(
            icon: Icon(Icons.menu),
            onPressed: () {
              // add menu functionality if needed
            },
          ),
          IconButton(
            icon: Icon(Icons.settings),
            onPressed: () {
              // add settings functionality if needed
            },
          ),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Welcome!",
                style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Text(
                "Log in to continue",
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
              SizedBox(height: 32),
              TextField(
                controller: emailController,
                decoration: InputDecoration(
                  labelText: "E-mail",
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 16),
              TextField(
                controller: passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: "Password",
                  border: OutlineInputBorder(),
                  suffix: TextButton(
                    child: Text("Forgot password?"),
                    onPressed: () {
                      // Implement forgot password functionality
                    },
                  ),
                ),
              ),
              SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _login,
                  child: Text("Log in"),
                ),
              ),
              SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Don't have an account?"),
                  TextButton(
                    onPressed: () {
                      Navigator.pushReplacementNamed(context, '/signup');
                    },
                    child: Text("Sign up"),
                  ),
                ],
              ),
              SizedBox(height: 32),
              // Popular Brands section
              Text(
                "Popular Brands",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 16),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    _brandLogo("assets/images/mercedes.png"),
                    SizedBox(width: 16),
                    _brandLogo("assets/images/audi.png"),
                    SizedBox(width: 16),
                    _brandLogo("assets/images/jaguar.png"),
                    SizedBox(width: 16),
                    TextButton(
                      onPressed: () {
                        // Action for "See all" (optional)
                      },
                      child: Text("See all"),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _brandLogo(String assetPath) {
    // Ensure that the asset exists in your assets directory
    return Image.asset(
      assetPath,
      height: 50,
      width: 50,
      fit: BoxFit.contain,
    );
  }
}
